# tceb-dashboard-builder

MICE Data Hub Dashboard Builder — React component สำหรับสร้างและแสดงผล dashboard แบบ drag-and-drop
ใช้งานได้สองแบบ: (1) Standalone SPA และ (2) Embedded npm package ใน host app

---

## การใช้งานแบบ npm package (สำหรับทีมอื่น)

### ติดตั้ง

```bash
# จาก .tgz file ที่ได้รับมา
npm install ./tceb-dashboard-builder-1.0.0.tgz
```

### Import ใน React app

```jsx
import React, { Suspense, lazy } from 'react';

const DashboardBuilder = lazy(() => import('tceb-dashboard-builder'));

function MyPage() {
  return (
    <Suspense fallback={<div>กำลังโหลด...</div>}>
      <DashboardBuilder
        apiBaseUrl="https://your-api.example.com"
      />
    </Suspense>
  );
}
```

### Props

| Prop | Type | Default | คำอธิบาย |
|------|------|---------|----------|
| `apiBaseUrl` | `string` | `https://localhost:7139` | URL ของ backend API |
| `useSampleData` | `boolean` | `false` | ใช้ sample data แทน API จริง (dev/demo) |

### Peer Dependencies (ต้องมีใน host app)

```json
{ "react": ">=18", "react-dom": ">=18" }
```

recharts, jspdf, html2canvas — **bundled แล้วใน package** ไม่ต้องติดตั้งแยก

### ซ่อน topbar ของ Dashboard Builder (ถ้า host app มี nav เอง)

```css
.your-page-wrapper .topbar { display: none !important; }
.your-page-wrapper .app-shell { padding-top: 12px !important; }
```

---

## Local development

```bash
npm install
npm run dev        # Vite dev server → http://localhost:5173/custom-dashboard/
```

---

## Build

```bash
npm run build       # Standalone SPA → dist-app/  (deploy ที่ /custom-dashboard/)
npm run build:lib   # npm package    → dist/       (แชร์ให้ทีมอื่น)
npm run build:all   # Build ทั้งสองแบบ
npm run pack        # build:lib แล้วสร้าง .tgz พร้อมแชร์
```

ผลลัพธ์:
- `dist/dashboard-builder.es.js` — ES module (Vite, modern bundlers)
- `dist/dashboard-builder.cjs.js` — CommonJS (webpack/CRA)
- `tceb-dashboard-builder-x.x.x.tgz` — ไฟล์สำหรับส่งให้ทีมอื่น

---

## Project ecosystem

| Component | Role | Tech |
|---|---|---|
| **tceb-core-api** | Backend REST API | .NET 8 / ASP.NET Core |
| **custom-dashboard** ← you are here | Dashboard builder component | React + Vite |
| **tceb-web** | Main web portal | React (CRA) |
| **Ocelot Gateway** | API Gateway → Blendata | Ocelot (.NET) |
| **Blendata** | Data warehouse | Spark SQL |

### Request flow

```
DashboardBuilder
      │  REST /datasource/widget/{key}
      ▼
tceb-core-api ──► Ocelot Gateway ──► Blendata (data warehouse)
```

---

## Versioning

เมื่อมี update ให้เพิ่ม version ใน `package.json` แล้ว:

```bash
npm run pack
# ส่ง tceb-dashboard-builder-x.x.x.tgz ให้ทีมที่ใช้งาน
```

ทีมที่รับไฟล์:
```bash
npm install ./tceb-dashboard-builder-1.1.0.tgz
```
